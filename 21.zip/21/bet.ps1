wget -o .\exp.exe “http://live.sysinternals.com/procexp.exe”
wget -o .\mon.exe “http://live.sysinternals.com/procmon.exe”
wget -o .\auto.exe “http://live.sysinternals.com/autoruns.exe”
wget -o .\adex.exe “http://live.sysinternals.com/adexplorer.exe”
wget -o .\view.exe “http://live.sysinternals.com/TCPView.exe”