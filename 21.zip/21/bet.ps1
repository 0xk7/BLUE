wget -o .\exp.exe “http://live.sysinternals.com/procexp.exe”
wget -o .\mon.exe “http://live.sysinternals.com/procmon.exe”
wget -o .\auto.exe “http://live.sysinternals.com/autoruns.exe”
wget -o .\gawr.exe “https://1.na.dl.wireshark.org/win64/Wireshark-win64-3.2.11.exe”
wget -o .\plus.exe “https://explorerplusplus.com/software/explorer++_1.3.5_x64.zip”
wget -o .\webint.exe “http://dl.google.com/chrome/install/375.126/chrome_installer.exe”